/**
 * 
 */
/**
 * @author Khủng long
 *
 */
module My2DGame {
	requires java.desktop;
}